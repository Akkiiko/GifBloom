<header>
    <div class="header__background"></div>

    <x-public.navigation />
</header>