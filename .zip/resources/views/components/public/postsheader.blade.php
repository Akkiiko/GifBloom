<div>
    <h1>{{ $title }}</h1>
    <p class="header__description">{{ $description }}</p>
</div>