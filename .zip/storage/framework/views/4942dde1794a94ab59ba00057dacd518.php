<div>
    <p>23 Comments</p>

    <form wire:submit="save(<?php echo e($id); ?>)">
        <div class="comment__input br__8 my-4 text-end">
            <textarea wire:model="content" placeholder="Post a comment..." class="w-100 br__8 m-0"></textarea>
            <button class="primary__button login__button mt-2 mx-0">Post Comment</button>
        </div>
    </form>
</div><?php /**PATH D:\GifBloom\resources\views/livewire/post-comments.blade.php ENDPATH**/ ?>