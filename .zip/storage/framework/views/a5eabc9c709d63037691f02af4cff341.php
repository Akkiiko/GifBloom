<div class="mb-4 d-flex gap-3 align-items-center">
    <img src="/images/users/defaultAvatar.png" width="45" height="45" class="br__8">
    <div>
        <a href="" class="post__title mb-0"><?php echo e($post->user->username); ?></a>
        <p class="post__description">Saturday 12th June 2023</p>
    </div>
</div><?php /**PATH D:\GifBloom\resources\views/components/public/postuser.blade.php ENDPATH**/ ?>