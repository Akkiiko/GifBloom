<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Laravel'); ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/styles.css')); ?>">
</head>
<body class="antialiased">
    
    <?php if (isset($component)) { $__componentOriginal37a191839d4b81c279735ab5630bbbeb = $component; } ?>
<?php $component = App\View\Components\Public\Navigation::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('public.navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Public\Navigation::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal37a191839d4b81c279735ab5630bbbeb)): ?>
<?php $component = $__componentOriginal37a191839d4b81c279735ab5630bbbeb; ?>
<?php unset($__componentOriginal37a191839d4b81c279735ab5630bbbeb); ?>
<?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>

</body>
</html>
<?php /**PATH D:\GifBloom\resources\views/layouts/home.blade.php ENDPATH**/ ?>