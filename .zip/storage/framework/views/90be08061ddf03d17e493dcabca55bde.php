<div class="post__container">
    <div class="post__thumbnail mb-4" style="background: linear-gradient(0deg, rgba(33, 33, 33, 0.85) 0%, rgba(33, 33, 33, 0.85) 100%), url('/images/tokyo_tower.svg'); background-repeat: no-repeat; background-size: cover; background-position-y: 50%;">
        <img alt="{user}'s image of {title}" src="/images/tokyo_tower.png">
    </div>

    <div class="d-flex justify-content-between">
        <div>
            <div class="d-flex gap-2">
                <p class="post__tag">#tokyo</p>
                <p class="post__tag">#japan</p>
                <p class="post__tag">#photograph</p>
            </div>
        
            <p class="post__title">Tokyo tower during the day</p>
            <p class="post__description">A picture from my first trip to Tokyo during the winter of 2023. It was a beautiful trip where I got up to many exciting things.</p>
        </div>
        
        <div class="text-center">
            <img alt="Like icon" src="/images/icons/unliked.png">
            <p class="like__count">53</p>
        </div>
    </div>
</div><?php /**PATH D:\GifBloom\resources\views/components/public/post.blade.php ENDPATH**/ ?>