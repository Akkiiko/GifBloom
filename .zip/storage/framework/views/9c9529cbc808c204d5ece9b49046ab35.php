<div class="post__container mb-4">
    <div class="post__thumbnail mb-4" style="background: linear-gradient(0deg, rgba(33, 33, 33, 0.85) 0%, rgba(33, 33, 33, 0.85) 100%), url('<?php echo e("/storage/$post->thumbnail"); ?>'); background-repeat: no-repeat; background-size: cover; background-position-y: 50%;">
        <img alt="{user}'s image of {title}" class="h-100 thumbnail" src="<?php echo e("/storage/$post->thumbnail"); ?>">
    </div>

    <div class="d-flex justify-content-between">
        <div>
            <div class="d-flex gap-2">
                <p class="post__tag">#tokyo</p>
                <p class="post__tag">#japan</p>
                <p class="post__tag">#photograph</p>
            </div>
        
            <p class="post__title"><?php echo e($post->title); ?></p>
            <p class="post__description"><?php echo e($post->content); ?></p>
        </div>
        
        <div class="text-center">
            <a class="pointer" <?php if(auth()->guard()->check()): ?> wire:click="toggleLike()" <?php else: ?> data-bs-toggle="modal" data-bs-target="#loginModal" <?php endif; ?>>
                <!--[if BLOCK]><![endif]--><?php if(Auth::check() && in_array($post->id, auth()->user()->likes->pluck('id')->all())): ?>
                    <img alt="Like icon" src="/images/icons/liked.png">
                <?php else: ?>
                    <img alt="Like icon" src="/images/icons/unliked.png">
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </button>
            <p class="like__count"><?php echo e($post->likes); ?></p>
            </a>
        </div>
    </div>
</div>
<?php /**PATH D:\GifBloom\resources\views/livewire/post/post.blade.php ENDPATH**/ ?>