<div class="post__container w-100 text-center">
    <img alt="Sad face" width="100" height="100" src="<?php echo e(asset('/images/icons/sad_face.png')); ?>">
    <h4 class="mt-4">Nothing Found</h4>
    <p class="post__description">Unfortunately, we were unable to find any posts.</p>
</div><?php /**PATH D:\GifBloom\resources\views/components/public/posts/notfound.blade.php ENDPATH**/ ?>