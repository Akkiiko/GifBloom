<div>
    <h1><?php echo e($title); ?></h1>
    <p class="header__description"><?php echo e($description); ?></p>
</div><?php /**PATH D:\GifBloom\resources\views/components/public/postsheader.blade.php ENDPATH**/ ?>