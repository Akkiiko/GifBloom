

<?php $__env->startSection('title', 'GifBloom - Each scroll is a story'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-sm-12 col-lg-9 m-auto">
            <div class="mb-4 d-flex gap-0 align-items-center">
                <img src="/images/users/defaultAvatar.png" width="45" height="45" class="br__8">
                <div class="w-100" style="margin-left: 15px;">
                    <a href=<?php echo e(route('profile', $post->user)); ?> class="post__title mb-0"><?php echo e($post->user->username); ?></a>
                    <div class="d-flex justify-content-between align-items-center">
                        <p class="post__description"><?php echo e($post->created_at->format('l jS F Y')); ?></p>
                        <a href=<?php echo e(route('profile', $post->user)); ?> class="post__description">View Profile</a>
                    </div>
                </div>
            </div>
            
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('post.post', ['post' => $post,'lazy.defer' => true]);

$__html = app('livewire')->mount($__name, $__params, 'uAGKuAd', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <p><?php echo e(count($post->comments)); ?> Comments</p>

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('post.create-comment', ['lazy.defer' => true,'id' => $post->id]);

$__html = app('livewire')->mount($__name, $__params, 'k1OSHlA', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('post.comment-list', ['lazy.defer' => true,'comments' => $post->comments]);

$__html = app('livewire')->mount($__name, $__params, 'iJTC3p7', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GifBloom\resources\views/post.blade.php ENDPATH**/ ?>