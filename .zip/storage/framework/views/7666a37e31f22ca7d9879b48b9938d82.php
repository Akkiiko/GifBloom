<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Laravel'); ?></title>
    <link rel="icon" type="image/png" href='<?php echo e(asset('/images/branding/logonotext.png')); ?>'>
    <meta property="og:title" content="<?php echo $__env->yieldContent('title', 'Laravel'); ?>" />
    <meta property="og:image" content='<?php echo e(asset('/images/branding/banner.png')); ?>' />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <?php if(!Auth::check()): ?><link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/auth.css')); ?>"> <?php endif; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/styles.css')); ?>">
</head>

<body>

    <?php if(auth()->guard()->check()): ?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('post.create-post', []);

$__html = app('livewire')->mount($__name, $__params, '5nvtb6e', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php endif; ?>

    <?php if(!Auth::check()): ?>
    <?php if (isset($component)) { $__componentOriginal075222fde8fa1450609a7bf95b2d1259 = $component; } ?>
<?php $component = App\View\Components\Public\Auth\Login::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('public.auth.login'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Public\Auth\Login::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal075222fde8fa1450609a7bf95b2d1259)): ?>
<?php $component = $__componentOriginal075222fde8fa1450609a7bf95b2d1259; ?>
<?php unset($__componentOriginal075222fde8fa1450609a7bf95b2d1259); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginaldc300f46a0885fa9aa70518b4d7ce92f = $component; } ?>
<?php $component = App\View\Components\Public\Auth\Register::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('public.auth.register'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Public\Auth\Register::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc300f46a0885fa9aa70518b4d7ce92f)): ?>
<?php $component = $__componentOriginaldc300f46a0885fa9aa70518b4d7ce92f; ?>
<?php unset($__componentOriginaldc300f46a0885fa9aa70518b4d7ce92f); ?>
<?php endif; ?>

    <?php if(session('show_login')): ?> 
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var loginModal = document.getElementById('loginModal');
    
            if (loginModal) {
                var modal = new bootstrap.Modal(loginModal);
                modal.show();
            }
        });
    </script>
    <?php endif; ?>

    <?php if(session('show_register')): ?> 
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var loginModal = document.getElementById('registerModal');
    
            if (loginModal) {
                var modal = new bootstrap.Modal(registerModal);
                modal.show();
            }
        });
    </script>
    <?php endif; ?>

    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal5316cbabc6601b492204040dff029a4f = $component; } ?>
<?php $component = App\View\Components\Public\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('public.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Public\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5316cbabc6601b492204040dff029a4f)): ?>
<?php $component = $__componentOriginal5316cbabc6601b492204040dff029a4f; ?>
<?php unset($__componentOriginal5316cbabc6601b492204040dff029a4f); ?>
<?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH D:\GifBloom\resources\views/layouts/app.blade.php ENDPATH**/ ?>