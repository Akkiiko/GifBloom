<div>
    <!--[if BLOCK]><![endif]--><?php if(auth()->guard()->guest()): ?>
    <div class="comment__input br__8 my-4">
        <textarea wire:model.defer="content" placeholder="Post a comment..." class="w-100 br__8 m-0"></textarea>
        <div class="d-flex justify-content-between align-items-center">
            <p class="error"><!--[if BLOCK]><![endif]--><?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]--></p>
            <button class="primary__button login__button mt-2 mx-0" data-bs-toggle="modal" data-bs-target="#loginModal">Post Comment</button>
        </div>
    </div>
    <?php else: ?>
        <form <?php if(auth()->guard()->check()): ?> wire:submit.prevent="save(<?php echo e($id); ?>)" <?php endif; ?>>
            <div class="comment__input br__8 my-4">
                <textarea wire:model="content" placeholder="Post a comment..." class="w-100 br__8 m-0"></textarea>
                <div class="d-flex justify-content-between align-items-center">
                    <p class="error"><!--[if BLOCK]><![endif]--><?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]--></p>
                    <button class="primary__button login__button mt-2 mx-0">Post Comment</button>
                </div>
            </div>
        </form>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH D:\GifBloom\resources\views/livewire/post-comment.blade.php ENDPATH**/ ?>