<?php $__env->startSection('title', 'GifBloom - Each scroll is a story'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-12 col-lg-9 large__gutter text-center text-lg-start mb-4" style="margin-left: auto;">
            <?php if (isset($component)) { $__componentOriginal2a54b7de45ba86e22a2199449f9de0f0 = $component; } ?>
<?php $component = App\View\Components\Public\Postsheader::resolve(['title' => 'Explore','description' => 'Every scroll you make, a new surprise awaits!'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('public.postsheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Public\Postsheader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a54b7de45ba86e22a2199449f9de0f0)): ?>
<?php $component = $__componentOriginal2a54b7de45ba86e22a2199449f9de0f0; ?>
<?php unset($__componentOriginal2a54b7de45ba86e22a2199449f9de0f0); ?>
<?php endif; ?>
        </div>             
    </div>

    <div class="row">
        <div class="col-12 col-lg-3 mb-4 d-fixed">
            <div class="sticky-column">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('post.filter', []);

$__html = app('livewire')->mount($__name, $__params, 'DK9UqyE', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
        <div class="col-12 col-lg-9 mb-4 large__gutter">
            <div>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('post.post-list', ['lazy.defer' => true]);

$__html = app('livewire')->mount($__name, $__params, 'KF03FdZ', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GifBloom\resources\views/home.blade.php ENDPATH**/ ?>