<div wire:ignore.self class="modal fade" id="uploadModal" tabindex="-1" aria-hidden="true"> 
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-body p-4">
          <form wire:submit="save">
            <!--[if BLOCK]><![endif]--><?php if($photo): ?> 
              <div class="text-center mb-4 br__8" style="background: linear-gradient(0deg, rgba(33, 33, 33, 0.85) 0%, rgba(33, 33, 33, 0.85) 100%), url('<?php echo e($photo->temporaryUrl()); ?>'); background-repeat: no-repeat; background-size: cover; background-position-y: 50%;">
                <img style="max-height: 200px" src="<?php echo e($photo->temporaryUrl()); ?>">
              </div>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            
            <div class="custom-file-input <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error__border br__8 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
              <label for="photo">Choose a file</label>
              <input type="file" wire:model.defer="photo" />
            </div>

            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
            
            <div class="mt-3">
              <label for="title">Title</label>
              <input wire:model="title" class="primary__input w-100 mt-2" type="text" required name="title" value="<?php echo e(old('title')); ?>" placeholder="A picture of Tokyo Tower...">
              <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error mt-3"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="mt-4">
              <label>Content</label>
              <textarea  wire:model="content" class="w-100 upload__post "></textarea>
              <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
  
            <button type="submit" class="primary__button m-0 w-100 mt-3 post__button">Post</button>
          </form>
        </div>
      </div>
    </div>
  </div><?php /**PATH D:\GifBloom\resources\views/livewire/post/create-post.blade.php ENDPATH**/ ?>