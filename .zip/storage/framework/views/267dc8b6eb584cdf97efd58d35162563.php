<header>
    <div class="header__background"></div>

    <?php if (isset($component)) { $__componentOriginal37a191839d4b81c279735ab5630bbbeb = $component; } ?>
<?php $component = App\View\Components\Public\Navigation::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('public.navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Public\Navigation::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal37a191839d4b81c279735ab5630bbbeb)): ?>
<?php $component = $__componentOriginal37a191839d4b81c279735ab5630bbbeb; ?>
<?php unset($__componentOriginal37a191839d4b81c279735ab5630bbbeb); ?>
<?php endif; ?>
</header><?php /**PATH D:\GifBloom\resources\views/components/public/header.blade.php ENDPATH**/ ?>