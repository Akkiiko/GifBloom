<div class="comment br__8 mb-4">
    <p class="comment__text post__description mb-3">“<?php echo e($comment->content); ?>”</p>
    
    <div class="d-flex justify-content-between">
        <div class="d-flex gap-2">
            <img src="<?php echo e($comment->user->avatar); ?>" width="30" height="30" class="br__8">
            <p class="comment__text post__title m-0"><?php echo e($comment->user->username); ?></p>
        </div>
        <p class="comment__text post__description m-0"><?php echo e($comment->created_at->format('l jS F Y')); ?></p>
    </div>
</div><?php /**PATH D:\GifBloom\resources\views/livewire/post/comment.blade.php ENDPATH**/ ?>